//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Simple.rc
//
#define IDC_MYICON                      2
#define IDD_MAINWINDOW                  101
#define IDD_SIMPLE_DIALOG               102
#define IDD_ABOUTBOX                    103
#define IDS_APP_TITLE                   103
#define IDM_ABOUT                       104
#define IDM_EXIT                        105
#define IDS_HELLO                       106
#define IDI_SIMPLE                      107
#define IDI_SMALL                       108
#define IDC_SIMPLE                      109
#define IDI_SMALL2                      109
#define IDR_MAINFRAME                   128
#define IDR_TRAYMENU                    130
#define IDR_VERMENU                     133
#define IDD_CHANINFO                    136
#define IDR_LTRAYMENU                   137
#define IDC_LIST1                       1000
#define IDC_BUTTON7                     1001
#define IDC_ABOUTVER                    1002
#define IDC_CHECK1                      1003
#define IDC_EDIT1                       1004
#define IDC_LIST2                       1005
#define IDC_EDIT_PLAYING                1005
#define IDC_COMBO1                      1006
#define IDC_EDIT_MESSAGE                1006
#define IDC_CHECK2                      1007
#define IDC_EDIT_NAME                   1007
#define IDC_BUTTON1                     1008
#define IDC_EDIT_DESC                   1008
#define IDC_DETAILS                     1009
#define IDC_MAXRELAYS                   1009
#define IDC_LIST3                       1010
#define IDC_PLAY                        1010
#define IDC_CONTACT                     1011
#define IDC_EDIT2                       1012
#define IDC_FORMAT                      1013
#define IDC_EDIT_GENRE                  1014
#define IDC_KEEP                        1015
#define IDC_EDIT_STATUS                 1016
#define IDC_EDIT_LISTENERS              1017
#define IDC_LIST4                       1018
#define IDC_EDIT_HOSTS                  1018
#define IDC_BUTTON4                     1019
#define IDC_BUTTON5                     1020
#define IDC_BUTTON6                     1021
#define IDC_EDIT3                       1025
#define IDC_EDIT5                       1027
#define IDC_LOGDEBUG                    1037
#define IDC_LOGNETWORK                  1038
#define IDC_LOGERRORS                   1039
#define IDC_CHECK9                      1041
#define IDC_BUTTON8                     1043
#define IDC_BUTTON10                    1046
#define IDC_BUTTON11                    1047
#define IDC_LOGCHANNELS                 1050
#define IDC_BUTTON2                     1056
#define IDC_EDIT4                       1058
#define IDC_BUTTON3                     1059
#define IDC_EDIT9                       1060
#define IDC_CHECK11                     1061
#define IDM_SETTINGS_GUI                32771
#define ID_POPUP_ABOUT                  32779
#define ID_POPUP_EXIT_CONFIRM           32781
#define ID_POPUP_EXIT_NO                32782
#define ID_POPUP_SETTINGS               32785
#define ID_POPUP_CONNECTIONS            32786
#define ID_POPUP_SHOWGUI                32788
#define ID_POPUP_ALLCHANNELS            32791
#define ID_POPUP_FAVORITES_EDIT         32792
#define ID_POPUP_ADVANCED_INFORMATION   32793
#define ID_POPUP_ADVANCED_SAVESETTINGS  32794
#define ID_POPUP_UPGRADE                32795
#define ID_POPUP_HELP                   32796
#define ID_POPUP_ADVANCED_VIEWLOG       32797
#define ID_POPUP_FAVORITES_PLAYALL      32798
#define ID_POPUP_ADVANCED_ALLCHANNELS   32799
#define ID_POPUP_ADVANCED_RELAYEDCHANNELS 32800
#define ID_POPUP_ADVANCED_BROADCAST     32801
#define ID_FIND_CHANNELS                32808
#define ID_POPUP_SHOWMESSAGES_PEERCAST  32814
#define ID_POPUP_SHOWMESSAGES_BROADCASTERS 32815
#define ID_POPUP_SHOWMESSAGES_TRACKINFO 32816
#define ID_POPUP_POPUPMESSAGES_UPGRADEALERTS 32817
#define ID_POPUP_YELLOWPAGES            32818
#define ID_POPUP_ADVANCED_SHOWGUI       32819
#define IDC_STATIC                      -1

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        142
#define _APS_NEXT_COMMAND_VALUE         32820
#define _APS_NEXT_CONTROL_VALUE         1016
#define _APS_NEXT_SYMED_VALUE           110
#endif
#endif
