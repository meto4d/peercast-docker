//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by SCRIPT1.RC
//
#define IDC_APPLY                       3
#define IDD_DIALOG1                     101
#define IDI_ICON1                       104
#define IDI_ICON2                       105
#define IDI_ICON3                       106
#define IDI_ICON4                       107
#define IDI_ICON5                       108
#define IDI_ICON6                       114
#define IDD_DIALOG2                     116
#define IDC_ENABLE                      1000
#define IDC_PREV                        1000
#define IDC_SENS                        1001
#define IDC_PREV2                       1001
#define IDC_UP                          1002
#define IDC_PREV3                       1002
#define IDC_COMBO1                      1003
#define IDC_PREV4                       1003
#define IDC_DOWN                        1004
#define IDC_W                           1004
#define IDC_PREV5                       1004
#define IDC_LEFT                        1005
#define IDC_H                           1005
#define IDC_RIGHT                       1006
#define IDC_COL                         1006
#define IDC_UP2                         1007
#define IDC_DOWN2                       1008
#define IDC_AUTOCONNECT                 1008
#define IDC_ACTIVE                      1008
#define IDC_LEFT2                       1009
#define IDC_EDIT1                       1009
#define IDC_MAXRELAYS                   1009
#define IDC_RIGHT2                      1010
#define IDC_CHECK2                      1010
#define IDC_BUTTON1                     1011
#define IDC_SETCOL                      1011
#define IDC_BUTTON2                     1012
#define IDC_EDIT2                       1012
#define IDC_BUTTON3                     1013
#define IDC_EDIT3                       1013
#define IDC_BUTTON4                     1014
#define IDC_EDIT4                       1014
#define IDC_CHECK3                      1015
#define IDC_EDIT5                       1016
#define IDC_OK                          1017
#define IDC_CANCEL                      1018
#define IDC_RADIO1                      1019
#define IDC_RADIO2                      1020
#define IDC_RADIO3                      1021
#define IDC_CHECK4                      1022
#define IDC_LIST1                       1023
#define IDPLAY                          1024
#define IDC_CHECK1                      1025
#define IDC_SPEED1                      1026
#define IDC_SPEED2                      1027
#define IDC_SPEED3                      1028
#define IDC_SPEED4                      1029
#define IDC_SPEED5                      1030
#define IDC_EDIT6                       1031

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        117
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1032
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
